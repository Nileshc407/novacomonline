<?php
$currentTime = date("Y-m-d H:i:s");
echo "current time---".$currentTime;
?>