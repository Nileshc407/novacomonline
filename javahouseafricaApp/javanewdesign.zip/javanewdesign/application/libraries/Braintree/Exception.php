<?php
/**
 * super class for all Braintree exceptions
 *
 * @package    Braintree
 * @subpackage Exception
 * @copyright  2014 Braintree, a division of PayPal, Inc.
 */
class Braintree_Exception extends Exception
{
}
