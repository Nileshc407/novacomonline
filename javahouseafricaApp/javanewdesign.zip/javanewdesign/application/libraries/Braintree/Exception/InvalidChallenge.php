<?php
class Braintree_Exception_InvalidChallenge extends Braintree_Exception
{

}
